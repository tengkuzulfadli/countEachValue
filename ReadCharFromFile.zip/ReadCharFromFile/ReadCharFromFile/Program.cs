﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ReadCharFromFile
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //To read a content inside character.txt file
            const string IMPORTFILE = "../../import/character.txt";
            const string EXPORTFILE = "export/character-count.txt";
            const string DIRECTORY = "EXPORT";

            //Declare a variable in array for each character

            char[] charactersArr = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            int[] charCounterArr = new int[26];

            using (StreamReader reader = new StreamReader(IMPORTFILE))
            {
                //string line = reader.ReadLine();
                //Console.WriteLine(line);

                //We wrap inside while loop to read array

                while (!reader.EndOfStream)
                {
                    int charInt = reader.Read();
                    char characterChar = Convert.ToChar(charInt);

                    //Declare an integer to find an array using Array.BinarySearch(first arg var that declare the character in array, second arg char that declare above)
                    int foundIndex = Array.BinarySearch(charactersArr, characterChar);

                    if (foundIndex >= 0)
                    {
                        //Increment the value if foundIndex is true, taking second var array declaration
                        charCounterArr[foundIndex]++;
                    }
                }

            }

            //To check if export folder and character-count file exist or not before create or write

            if (!Directory.Exists(DIRECTORY))
            {
                Directory.CreateDirectory(DIRECTORY);
            }

            using (StreamWriter writer = new StreamWriter(EXPORTFILE))
            {
                //Using for loop to count how many char in character.txt

                for (int index = 0; index < charactersArr.Length; index++)
                {
                    Console.WriteLine(charactersArr[index] + " " + charCounterArr[index]);
                    writer.WriteLine(charactersArr[index] + " " + charCounterArr[index]);
                }
            }

            Console.ReadKey();
        }
    }
}
